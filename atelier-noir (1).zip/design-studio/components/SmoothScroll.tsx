"use client";

import Lenis from "lenis";
import { useEffect } from "react";

/**
 * Wraps the app in a global Lenis smooth-scroll instance.
 * Kept separate from Skiper30's own local Lenis init so the whole
 * page (nav, portfolio, collections) scrolls with the same easing,
 * not just the hero.
 */
export function SmoothScroll({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 1.5,
    });

    let rafId: number;
    function raf(time: number) {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    }
    rafId = requestAnimationFrame(raf);

    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
    };
  }, []);

  return <>{children}</>;
}
